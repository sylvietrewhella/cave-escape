//
//  SGSDL2Input.h
//  sgsdl2
//
//  Created by Andrew Cain on 7/12/2013.
//  Copyright (c) 2013 Andrew Cain. All rights reserved.
//

#ifndef __sgsdl2__SGSDL2Input__
#define __sgsdl2__SGSDL2Input__

#include "sgInterfaces.h"

void sgsdl2_load_input_fns(sg_interface *functions);

#endif /* defined(__sgsdl2__SGSDL2Input__) */
